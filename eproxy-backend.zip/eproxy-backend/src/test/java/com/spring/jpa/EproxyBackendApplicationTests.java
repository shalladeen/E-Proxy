package com.spring.jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EproxyBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
