package com.eproxy.backend.dto;

public class DashboardSummary {

    private long open;
    private long pending;
    private long resolved;
    private long total;

    public DashboardSummary(long open, long pending, long resolved, long total) {
        this.open = open;
        this.pending = pending;
        this.resolved = resolved;
        this.total = total;
    }

    public long getOpen() { return open; }
    public long getPending() { return pending; }
    public long getResolved() { return resolved; }
    public long getTotal() { return total; }
}
