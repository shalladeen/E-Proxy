package com.eproxy.backend.controller;

import com.eproxy.backend.dto.DashboardSummary;
import com.eproxy.backend.model.Ticket;
import com.eproxy.backend.repository.TicketRepository;
import org.springframework.http.ResponseEntity;        
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;                               

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:5173")
public class TicketController {

    private final TicketRepository ticketRepository;

    public TicketController(TicketRepository ticketRepository) {
        this.ticketRepository = ticketRepository;
    }

    @GetMapping("/tickets")
    public List<Ticket> getTickets() {
        return ticketRepository.findAll();
    }

    @PostMapping("/tickets")
    public Ticket createTicket(@RequestBody Ticket ticket) {

        if (ticket.getStatus() == null || ticket.getStatus().isBlank()) {
            ticket.setStatus("Open");
        }
        if (ticket.getUpdatedAt() == null) {
            
            ticket.setUpdatedAt(LocalDateTime.now().toString());
        }

        return ticketRepository.save(ticket);
    }

    
    @PutMapping("/tickets/{id}/status")
    public ResponseEntity<Ticket> updateTicketStatus(
            @PathVariable Long id,                  
            @RequestBody Map<String, String> body
    ) {
        String newStatus = body.get("status");
        if (newStatus == null || newStatus.isBlank()) {
            return ResponseEntity.badRequest().build();
        }

        return ticketRepository.findById(id)
                .map(ticket -> {
                    ticket.setStatus(newStatus);
                    ticket.setUpdatedAt(LocalDateTime.now().toString());
                    Ticket saved = ticketRepository.save(ticket);
                    return ResponseEntity.ok(saved);
                })
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/dashboard/summary")
    public DashboardSummary getDashboardSummary() {
        List<Ticket> tickets = ticketRepository.findAll();

        long open = tickets.stream().filter(t -> "Open".equalsIgnoreCase(t.getStatus())).count();
        long pending = tickets.stream().filter(t -> "Pending".equalsIgnoreCase(t.getStatus())).count();
        long resolved = tickets.stream().filter(t -> "Resolved".equalsIgnoreCase(t.getStatus())).count();
        long total = tickets.size();

        return new DashboardSummary(open, pending, resolved, total);
    }
}
