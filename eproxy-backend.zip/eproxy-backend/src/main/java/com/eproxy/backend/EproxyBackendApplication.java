package com.eproxy.backend;

import com.eproxy.backend.model.Ticket;
import com.eproxy.backend.repository.TicketRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class EproxyBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(EproxyBackendApplication.class, args);
    }

    
    @Bean
    CommandLineRunner initTickets(TicketRepository repo) {
        return args -> {
            if (repo.count() == 0) {
                repo.save(make("#1023", "Jane Doe", "Payment not going through", "Open", "High", "2025-12-01 14:32"));
                repo.save(make("#1024", "Acme Corp", "Cannot access dashboard", "Pending", "Medium", "2025-12-02 09:15"));
                repo.save(make("#1025", "John Smith", "Wrong invoice amount", "Resolved", "Low", "2025-12-02 11:47"));
                repo.save(make("#1026", "Brightline Studio", "Need help setting up webhooks", "Open", "High", "2025-12-03 08:21"));
                repo.save(make("#1027", "CloudNine", "Account suspended unexpectedly", "Pending", "High", "2025-12-03 10:02"));
            }
        };
    }

    private Ticket make(String id, String customer, String subject,
                        String status, String priority, String updatedAt) {
        Ticket t = new Ticket();
        t.setId(id);
        t.setCustomer(customer);
        t.setSubject(subject);
        t.setStatus(status);
        t.setPriority(priority);
        t.setUpdatedAt(updatedAt);
        return t;
    }
}
